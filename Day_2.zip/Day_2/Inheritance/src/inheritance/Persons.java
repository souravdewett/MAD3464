/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author souravdewett
 */
import java.util.*;
public class Persons {
    String firstName;
    String lastName;
    int age;
    
    //default constructor
    
    Persons()
    {
        this.firstName ="Unknown";
        this.lastName = "Unknown";
        this.age = 1;
    }
    
    //Parameterized constructor
    Persons(String fNM,String lNM,int age)
    {
        this.firstName = fNM;
        this.lastName = lNM;
        this.age = age;
    }
    
    //copy constructor
    
    Persons(Persons object)
    {
        this.firstName = object.firstName;
        this.lastName = object.lastName;
        this.age= object.age;
        
    }
    void read()
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter First Name");
        firstName = sc.nextLine();
        
        System.out.println("Enter last Name");
        lastName = sc.nextLine();
        
        System.out.println("Enter Person's age");
        age = sc.nextInt();
    }
    
    void display()
    {
        System.out.println("First Name is:"+this.firstName);
        System.out.println("Last  Name is:"+this.lastName);
        System.out.println("Age is:"+this.age);
    }
}
