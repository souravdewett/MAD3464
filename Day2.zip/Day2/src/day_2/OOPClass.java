/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day_2;

/**
 *
 * @author sourav
 */
import java.util.*;


public class OOPClass {
    public static void main(String[] args)
    {
        String Cust_Name;
        //create a new object of main class
        Bank myBank = new Bank();
        
        System.out.println("Bank ID:" + myBank.bankID);
        System.out.println("Bank Name:"+ myBank.bankName);
        
        Bank yourBank = new Bank();
        
        myBank.bankID = 1231;
        myBank.bankName = "RBC";
        
        System.out.println("Bank ID:" + myBank.bankID);
        System.out.println("Bank Name:"+ myBank.bankName);
        
        myBank.getBankName();
        yourBank.setBankName("Scotia");
        yourBank.getBankName();
        
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("Enter Customer Name");
        Cust_Name = sc.nextLine();
        
        yourBank.setBankName(Cust_Name);
        yourBank.getBankName();
        
        Arithmatic add = new Arithmatic();
        
      /* System.out.println("The addition of two variables is:" +add.addition(5,6));
       System.out.println("The addition of two float variables is:" +add.addition(5.1f,6.2f));
       System.out.println("the addition of three variables is :"+add.addition(10,20,30));
       */
       System.out.println("the multiplication of three variables is :"+add.multiplication(2,4,5));

       add.multiplication(10,20);
      
}
}
