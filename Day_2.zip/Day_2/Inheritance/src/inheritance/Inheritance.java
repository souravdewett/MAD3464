/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author souravdewett
 */
public class Inheritance {
public static void main(String[] args)
{
    Persons obj = new Persons();
    //obj.readData();
    obj.display();
    
    Persons obj1 = new Persons("Sourav","Cheema",20);
    obj1.display();
    
    Persons obj2 = new Persons(obj1);
    obj2.display();
    
    //Employee e1 = new Employee(1450.07);
  //  e1.display();
    
    Employee e2 = new Employee();
    e2.display();
    
    e2.firstName = "Sourav";
    e2.lastName = "Cheema";
    e2.age = 20;
    e2.salary = 1000;
    e2.display();
    e2.display();
    
    //method oveririding
    Employee e3 = new Employee();
    e3.read();
    e3.display();
    //System.out.println("Last name:" + e2.lastName);
    }
}